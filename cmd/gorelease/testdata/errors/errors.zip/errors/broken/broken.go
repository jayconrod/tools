package broken

const X int = "no longer an int"
