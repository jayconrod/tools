package a

func A() int { return 1 }
