package nest

func B() int { return 3 }
