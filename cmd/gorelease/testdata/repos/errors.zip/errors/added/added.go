package added

const X int = "not an int"
