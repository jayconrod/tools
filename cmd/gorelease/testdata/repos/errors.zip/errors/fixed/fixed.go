package fixed

const X int = 12
