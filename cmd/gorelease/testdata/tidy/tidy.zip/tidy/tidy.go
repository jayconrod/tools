package tidy

import _ "rsc.io/quote"
