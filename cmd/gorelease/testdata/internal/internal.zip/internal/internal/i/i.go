package i

type I interface{
  Foo()
}
