package p

import "example.com/m/internal/i"

type P i.I
